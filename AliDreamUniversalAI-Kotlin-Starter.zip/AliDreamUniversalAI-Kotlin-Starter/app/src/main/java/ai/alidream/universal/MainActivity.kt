package ai.alidream.universal

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val ASSISTANT_ENDPOINT = "https://ali-dream-universal-ai-rktyd3.v2.appdeploy.ai/api/assistant"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AliDreamScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AliDreamScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var request by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Sannu! Ni ne Ali Dream Universal AI. Me zan taimaka maka?") }
    var busy by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("Hausa") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) request = spoken
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeech(context, language, speechLauncher::launch)
        else errorText = "Ba a ba da izinin makirufo ba. Za ka iya rubuta umarninka."
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Ali Dream Universal AI") }) }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Mataimakin AI na Android", style = MaterialTheme.typography.titleLarge)
                Text("MVP na farko • Hausa da English • Aiki ta backend mai tsaro")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = language == "Hausa", onClick = { language = "Hausa" }, label = { Text("Hausa") })
                    FilterChip(selected = language == "English", onClick = { language = "English" }, label = { Text("English") })
                }
                OutlinedTextField(
                    value = request, onValueChange = { request = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Rubuta umarni") }, placeholder = { Text("Misali: Ka taimaka min tsara aikina yau") }, minLines = 3
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) launchSpeech(context, language, speechLauncher::launch)
                        else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Text("Yi magana") }
                    Button(enabled = !busy && request.isNotBlank(), onClick = {
                        busy = true
                        errorText = null
                        scope.launch {
                            try { reply = askAliDream(request.trim(), language) }
                            catch (_: Exception) { errorText = "Ba a samu amsa ba. Duba intanet sannan ka sake gwadawa." }
                            finally { busy = false }
                        }
                    }) { Text(if (busy) "Ana aiki..." else "Aika") }
                }
                if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                errorText?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Amsar Ali Dream", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(reply)
                    }
                }
                Text(
                    "Iyakoki: wannan sigar tana aika tambaya zuwa AI kuma tana karɓar amsa. Ba ta da ikon sarrafa dukkan apps ko yin aiki a ɓoye. Za a ƙara ayyukan na'ura ne ta hanyar Android intents da izinin mai amfani.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun launchSpeech(context: android.content.Context, language: String, speechLauncher: (Intent) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language == "Hausa") "ha-NG" else "en-US")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Yi magana yanzu")
    }
    speechLauncher(intent)
}

private suspend fun askAliDream(message: String, language: String): String = withContext(Dispatchers.IO) {
    val connection = URL(ASSISTANT_ENDPOINT).openConnection() as HttpURLConnection
    try {
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 30000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.setRequestProperty("Accept", "application/json")
        val payload = JSONObject().put("message", message).put("language", language).toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (status !in 200..299) throw IllegalStateException("HTTP $status")
        JSONObject(body).optString("reply").ifBlank { "Na samu amsa marar cikawa. Ka sake gwadawa." }
    } finally { connection.disconnect() }
}
