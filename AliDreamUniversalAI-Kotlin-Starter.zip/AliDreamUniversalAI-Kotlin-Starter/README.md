# Ali Dream Universal AI — Kotlin Android Starter

This is a native Android source starter, **not a compiled APK**. It contains a Kotlin + Jetpack Compose interface, Hausa/English selection, user-initiated speech recognition, microphone permission, and an HTTPS connection to the existing Ali Dream backend.

## Build requirements
1. Use Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Install Android SDK 35 and use JDK 17.
4. Sync Gradle, then run on an emulator or real Android phone.
5. Test text chat first; then test microphone permission and speech recognition.

## Backend
The app calls `https://ali-dream-universal-ai-rktyd3.v2.appdeploy.ai/api/assistant` with JSON fields `message` and `language`, and expects a JSON `reply` field.

## Safety and limitations
- Do not place private provider API keys in Android source code. Keep secrets on the backend.
- This MVP sends user requests to the Ali Dream backend for an AI reply.
- Hausa speech recognition depends on the installed speech provider and device support.
- This starter does not secretly control other apps, read private messages, send WhatsApp messages, or download videos.
- Future device actions should use Android intents first, with clear consent and confirmation for consequential actions.
- WorkManager is for eligible deferred background work, not unlimited background control or continuous hidden listening.
- This project has not been compiled or tested on a physical device in this environment.

## Kotlin GPTs
A ChatGPT Custom GPT is not automatically a callable API for another app. Use it as a coding helper, or recreate the needed behavior through a backend API. Public GPT result: https://chatgpt.com/g/g-46iTuBBFU-kotlin .
