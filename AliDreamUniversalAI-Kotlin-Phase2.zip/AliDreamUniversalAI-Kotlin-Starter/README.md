# Ali Dream Universal AI — Kotlin Android Starter

This is a native Android source starter, **not a compiled APK**. It contains a Kotlin + Jetpack Compose interface, Hausa/English selection, user-initiated speech recognition, microphone permission, an HTTPS connection to the existing Ali Dream backend, a permission-based action router, and WorkManager reminders.

## Build requirements
1. Use Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Install Android SDK 35 and use JDK 17.
4. Sync Gradle, then run on an emulator or real Android phone.
5. Test text chat first; then test microphone permission and speech recognition.

## Backend
The app calls `https://ali-dream-universal-ai-rktyd3.v2.appdeploy.ai/api/assistant` with JSON fields `message` and `language`, and expects a JSON `reply` field.

## Supported device actions in this phase

Commands are handled locally before the general AI request when they match these patterns:
- `youtube <search terms>` or `search youtube for <search terms>` opens a YouTube search.
- `whatsapp <message>` or `message on whatsapp <message>` opens WhatsApp with a prefilled draft; the user must review and send it.
- `open settings` opens Android Settings.
- `remind me in 10 minutes to drink water` or `tunatar da ni cikin 10 mintuna akan shan ruwa` schedules a WorkManager reminder.

Reminder notifications require notifications to be allowed in Android settings. WorkManager can be delayed by Android battery and scheduling rules; it is not a real-time alarm guarantee. Unsupported commands still go to the AI backend for guidance, and are not falsely reported as executed.

## Safety and limitations
- Do not place private provider API keys in Android source code. Keep secrets on the backend.
- This MVP sends user requests to the Ali Dream backend for an AI reply. Supported local actions are limited to the explicit patterns above.
- Hausa speech recognition depends on the installed speech provider and device support.
- This starter does not secretly control other apps, read private messages, send WhatsApp messages, or download videos.
- Future device actions should use Android intents first, with clear consent and confirmation for consequential actions.
- WorkManager is for eligible deferred background work, not unlimited background control or continuous hidden listening.
- This project has not been compiled or tested on a physical device in this environment.

## Kotlin GPTs
A ChatGPT Custom GPT is not automatically a callable API for another app. Use it as a coding helper, or recreate the needed behavior through a backend API. Public GPT result: https://chatgpt.com/g/g-46iTuBBFU-kotlin .
